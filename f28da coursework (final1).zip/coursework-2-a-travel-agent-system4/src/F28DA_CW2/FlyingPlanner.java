package F28DA_CW2;
import java.util.*;
import org.jgrapht.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.AllDirectedPaths;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DirectedAcyclicGraph;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;


public class FlyingPlanner implements IFlyingPlannerPartB<Airport, Flight>, IFlyingPlannerPartC<Airport, Flight> {
//	private HashMap <String, Flight> flightMap = new HashMap (); 
//	private HashMap <String, Airport> airportMap = new HashMap();
	private SimpleDirectedWeightedGraph<Airport, Flight> g;
	private HashMap<String, Airport> airports = new HashMap<>();
	private HashMap<String, Flight> flights = new HashMap<>();
	private Graph<Airport, FlightEdge> costWeightedGraph = new SimpleDirectedWeightedGraph<>(FlightEdge.class);
	private Graph<Airport, FlightEdge> hopUnweightedGraph = new SimpleDirectedGraph<>(FlightEdge.class);
	private DirectedAcyclicGraph<Airport, FlightEdge> directedAcyclicGraph;
	private DirectedAcyclicGraph<Airport, FlightEdge> betterdirectedAcyclicGraph;
	private HashMap<Airport, Integer> directConnections = new HashMap<Airport, Integer>();

	//this method is to populate the graph g with vertices and edges based on the information in the airports and flights hash maps.
	//g: refers to creating a duplicate of the main graph that is initially empty.
	private boolean populate(HashMap<String, Airport> airports, HashMap<String, Flight> flights, Graph<Airport, FlightEdge> g, boolean weight) {
		  airports.values().forEach(g::addVertex);
		  for (Flight flight : flights.values()) {
		    Airport from = flight.getFrom();
		    Airport to = flight.getTo();
		    g.addEdge(from, to, new FlightEdge(flight));
		    if (weight== true) {
		      g.setEdgeWeight(from, to, flight.getCost());
		      //true only if the new empty graph has weighted edges,
		      //false if the new empty graph has unweighted edges.
		    }
		  }
		  return true;
		  //graph is successfully populated 
		}

	@Override
	// this method adds vertices to a graph for each airport and edges between airports for each flight in the data sets
	public boolean populate(FlightsReader fr) {
		//fr is from the FlightsReader class that reads the airports and flights information.
		HashSet<String[]> airportList = fr.getAirports();
		HashSet<String[]> flightList = fr.getFlights();
		return populate(airportList, flightList);
	}

	@Override
	//populates two graphs (cost-weighted graph, hop-unweighted graph)
	//populates it with airports and flights from two sets of data, airportList and flightList.
	public boolean populate(HashSet<String[]> airportList, HashSet<String[]> flightList) {
		for (String[] a : airportList) {
			//airportList = hashSet that contain airport information
			Airport addAirports = new Airport(a[0], a[1], a[2]);
			airports.put(a[0], addAirports);
			costWeightedGraph.addVertex(addAirports);
			hopUnweightedGraph.addVertex(addAirports);
		}

		for (String[] f : flightList) {
			//flightList = hashSet that contain flight information
			Airport from = airports.get(f[1]);
			Airport to = airports.get(f[3]);
			Flight flight = new Flight(f[0], from, f[2], to, f[4], Integer.parseInt(f[5]));
//			g.addEdge(from, to, flight);
			flights.put(f[0], flight);
			costWeightedGraph.addEdge(from, to, new FlightEdge(flight));
			costWeightedGraph.setEdgeWeight(from, to, Integer.parseInt(f[5]));
			hopUnweightedGraph.addEdge(from, to, new FlightEdge(flight));
		}
		return true;
	}
	
	//return airport object
	@Override
	public Airport airport(String code) {
		return airports.get(code);
	}
	
	//return flight object
	@Override
	public Flight flight(String code) {
		return flights.get(code);
	}

	//private method to find the least cost journey from one airport to another airport using Dijkstra's shortest path algorithm.
	//takes in the source airport code, destination airport code, and a graph of airports and flights.

	private Journey leastCost(String from, String to, Graph<Airport, FlightEdge> g) throws FlyingPlannerException {
	    Airport fromAirport = airport(from);
	    Airport toAirport= airport(to);
	    
	    //use Dijkstra's shortest path algorithm to find the least cost path
	    GraphPath<Airport, FlightEdge> dijkstraShortestPath = DijkstraShortestPath.findPathBetween(g, fromAirport, toAirport);
	    
	    Journey leastCostJourney;
	    Journey leastHopJourney = leastHop(from, to);
	    if (dijkstraShortestPath == null) {
	        throw new FlyingPlannerException("Journey is not available.");
	    } else {
	        leastCostJourney = new Journey(fromAirport, toAirport, dijkstraShortestPath);
	        if (leastCostJourney.totalCost() != leastHopJourney.totalCost()) {
	        	//return the least cost journey if least cost and least hop journeys have different total costs
	            return leastCostJourney;
	        }
	    }
	    //return the least hop journey if least cost and least hop journeys have the same total cost
	    return leastHopJourney;
	}


	@Override
	//finds the least cost journey from one airport to another using the costWeightedGraph
	public Journey leastCost(String from, String to) throws FlyingPlannerException {
		return leastCost(from, to, costWeightedGraph);
	}
	
	@Override
	//finds the least cost journey between two airports excluding the airports inputed by user 
	public Journey leastCost(String from, String to, List<String> excluding) throws FlyingPlannerException {
	    Graph<Airport, FlightEdge> cloneGraph = new SimpleDirectedWeightedGraph<>(FlightEdge.class);
	    // create a clone graph
	    populate(airports, flights, cloneGraph, true);
	    
	    // remove the airports specified by user from the clone graph
	    for (int i = 0; i < excluding.size(); i++) {
	        String code = excluding.get(i);
	        Airport airport = airport(code);
	        cloneGraph.removeVertex(airport);
	    }
	    // find the least cost journey using Dijkstra's algorithm and return it
	    return leastCost(from, to, cloneGraph);
	}
	
	// additional private method to calculate the journey with the least number of hops 
	private Journey leastHop(String from, String to, Graph<Airport, FlightEdge> wGraph, Graph<Airport, FlightEdge> uwGraph) throws FlyingPlannerException {
	    Airport fromAirport= airport(from);
	    Airport toAirport = airport(to);
	    GraphPath<Airport, FlightEdge> shortestPath = DijkstraShortestPath.findPathBetween(uwGraph, fromAirport, toAirport);

	    if (shortestPath == null) {
	        throw new FlyingPlannerException("Journey is not available.");
	    }
	    // list to get all the possible paths from the departure airport to the destination airport
	    List<GraphPath<Airport, FlightEdge>> pathList = new AllDirectedPaths<>(wGraph).getAllPaths(fromAirport, toAirport, true, shortestPath.getLength());
	    // calculate min cost of all the paths with the same number of hops
	    double minCost = Collections.min(pathList, Comparator.comparingDouble(GraphPath::getWeight)).getWeight();
	    List<GraphPath<Airport, FlightEdge>> minList = new LinkedList<>();
	    List<Integer> timeList = new LinkedList<>();

	    // find the paths with the min cost and store them in minList
	    for (GraphPath<Airport, FlightEdge> path : pathList) {
	        Journey j = new Journey(fromAirport, toAirport, path);
	        if (j.totalCost() == minCost) {
	            minList.add(path);
	            timeList.add(j.totalTime());
	        }
	    }
	    // select the path with the min total time amongst the paths with the same cost
	    GraphPath<Airport, FlightEdge> leastHopCostTime = minList.get(timeList.indexOf(Collections.min(timeList)));
	    return new Journey(fromAirport, toAirport, leastHopCostTime);
	}


	@Override
	//method that finds the journey with the least number of hops between from and to airport using an unweighted graph
	public Journey leastHop(String from, String to) throws FlyingPlannerException {
		return leastHop(from, to, costWeightedGraph, hopUnweightedGraph);
	}
	
	//method returns least connections, least cost,least journey time from one airport to another,
	//exclude a list of airports inputed by user
	
	@Override
	public Journey leastHop(String from, String to, List<String> excluding) throws FlyingPlannerException {
		Graph<Airport, FlightEdge> weightedGraph = new SimpleDirectedWeightedGraph<>(FlightEdge.class);
		populate(airports, flights, weightedGraph, true);
		Graph<Airport, FlightEdge> unweightedGraph = new SimpleDirectedGraph<>(FlightEdge.class);
		populate(airports, flights, unweightedGraph, false);

		for (String code : excluding) {
			Airport a = airport(code);
			weightedGraph.removeVertex(a);
			unweightedGraph.removeVertex(a);
		}
		//return modified graphs to find the journey with the least number of hops
		return leastHop(from, to, weightedGraph, unweightedGraph);
	}
	//find the fastest and cheapest journey between two airports within a specified number of flights
	private Journey leastTime(String from, String to, Graph<Airport, FlightEdge> wGraph, int num) throws FlyingPlannerException {
		AllDirectedPaths<Airport, FlightEdge> allPaths = new AllDirectedPaths<Airport, FlightEdge>(wGraph);
		Airport fromAirport = airport(from);
		Airport toAirport = airport(to);
		List<GraphPath<Airport, FlightEdge>> pathList = allPaths.getAllPaths(fromAirport, toAirport, true, num);
		
		if (pathList.size() == 0) {
			throw new FlyingPlannerException("Journey not available.");
		} else {
			// calculates the duration of each path by creating a Journey object and adding the duration to a list
			List<Integer> duration = new LinkedList<Integer>();
			for (GraphPath<Airport, FlightEdge> path : pathList) {
				Journey j = new Journey(fromAirport, toAirport, path);
				duration.add(j.totalTime());
			}
			//calculates the cost of the journey using the Journey object and adds the cost to another list
			int minTime = Collections.min(duration);
			List<GraphPath<Airport, FlightEdge>> minList = new LinkedList<>();
			List<Integer> costList = new LinkedList<>();
			for (GraphPath<Airport, FlightEdge> path : pathList) {
				Journey j = new Journey(fromAirport, toAirport, path);
				if (j.totalTime() == minTime) {
					minList.add(path);
					costList.add(j.totalCost());
				}
			}
			//finds the minimum cost 
			int minCost = Collections.min(costList);
			int index = costList.indexOf(minCost);
			GraphPath<Airport, FlightEdge> leastTimeLeastCostPath = minList.get(index);
			Journey leastTimeJourney = new Journey(fromAirport, toAirport, leastTimeLeastCostPath);
			return leastTimeJourney;
		}
	}
	//returns a least journey time flight journey from one airport to another
	public Journey leastTime(String from, String to, int num) throws FlyingPlannerException {
		return leastTime(from, to, costWeightedGraph, num);
	}
			
	@Override
	//calculate the number of direct connections for each airport 
	public int setDirectlyConnected() {
	    int sum = 0;
	    //to store the total number of direct connections across all airports.
	    for (Airport a : airports.values()) {
	    	//stores the size of the set in a map "directConnections"
	        Set<Airport> directAirport = a.getDicrectlyConnected(); // get directly connected airports
	        directConnections.put(a, directAirport.size()); // store size in map
	        sum += directAirport.size(); // add size to sum
	    }
	    //returns the total number of direct connections across all airports 
	    return sum;
	}
	
	@Override
	//create a directed acyclic graph that represents the airports and flights in the system
	//for flights flying to an airport destination with high number of directly connected airports than the origin airport.
	public int setDirectlyConnectedOrder() {
	    betterdirectedAcyclicGraph = new DirectedAcyclicGraph<>(FlightEdge.class);
	    //FlightEdge class represents the edge in the graph that connects two airports
	    
	    for (Airport a : airports.values()) {
	        betterdirectedAcyclicGraph.addVertex(a);
	    }
	    
	    for (Flight f : flights.values()) {
	        Airport from = f.getFrom();
	        Airport to = f.getTo();
	        if (directConnections.get(to) > directConnections.get(from)) {
	            betterdirectedAcyclicGraph.addEdge(from, to, new FlightEdge(f));
	        }
	    }
	    return betterdirectedAcyclicGraph.edgeSet().size();
	}


	@Override
	// returns the set of airports nearby from the given airport that have  more direct connections
	public Set<Airport> getBetterConnectedInOrder(Airport airport) {
		// Get all airports that are directly connected to the given airport
		Set<Airport> betterConnected = betterdirectedAcyclicGraph.getDescendants(airport);
		// Set the number of directly connected airports in order for the given airport
		airport.setDicrectlyConnectedOrder(betterConnected.size());
		// Return the set of better connected airports
		return betterConnected;
	}
	
	//returns a list of airport codes which are the connection airports between the origin airport and destination airport 
	private List<String> leastCostFixedHop(String from, String to, Graph<Airport, FlightEdge> wGraph, int num) {
		Airport fromA = airport(from);
		Airport toA = airport(to);
		AllDirectedPaths<Airport, FlightEdge> allPaths = new AllDirectedPaths<Airport, FlightEdge>(wGraph);
		List<GraphPath<Airport, FlightEdge>> pathList = allPaths.getAllPaths(fromA, toA, true, num);
		
		// filter out the paths that have only one edge and store them in a new list
		List<GraphPath<Airport, FlightEdge>> pathNumList = new LinkedList<GraphPath<Airport, FlightEdge>>();

		for (GraphPath<Airport, FlightEdge> gPath : pathList) {
			if (gPath.getEdgeList().size() != 1) {
				pathNumList.add(gPath);
			}
		}

		Set<String> codeSet = new HashSet<String>();
		for (GraphPath<Airport, FlightEdge> gPath : pathNumList) {
		    List<Airport> aplist = gPath.getVertexList();
		    for (Airport ap : aplist) {
		        String apStr = ap.getCode();
		        if (!apStr.equalsIgnoreCase(from) && !apStr.equalsIgnoreCase(to)) {
		            codeSet.add(apStr);
		        }
		    }
		}
		// convert the set of airport codes to a list and return it
		List<String> codeList = new LinkedList<String>(codeSet);
		return codeList;
	}
	
	@Override
	//method that returns the code the mopst suitable airport for the meet up of two different airport locations 
	//using cost
	public String leastCostMeetUp(String at1, String at2) throws FlyingPlannerException {
	    List<String> codeList = new LinkedList<>();
	    int num = 0;
	    int j = 0;
	    final int maxNum = 30; //maximum number of airports 
	    final int maxJ = 6;

	    while (num < maxNum && j < maxJ) {
	        codeList = leastCostFixedHop(at1, at2, costWeightedGraph, j);
	        //costWeightedGraph represents the graph that contains information about the cost of each flight.
	        num = codeList.size();
	        j++;
	    }

	    int minimumCost = Integer.MAX_VALUE;
	    String meetStop = null;

	    for (String code : codeList) {
	        Journey journey1 = leastCost(at1, code);
	        Journey journey2 = leastCost(at2, code);
	        int cost = journey1.totalCost() + journey2.totalCost();

	        if (cost < minimumCost) {
	            minimumCost = cost;
	            meetStop = code;
	        }
	    }
	    return meetStop;
	}
	
	@Override
	//method that returns the code the mopst suitable airport for the meet up of two different airport locations 
	//using cost
	public String leastHopMeetUp(String at1, String at2) throws FlyingPlannerException {
	    List<String> codeList = new LinkedList<String>();
	    //used to calculate the least number of hops.
	    int num, j = 0;
	    final int maxNum = 30; //
	    final int maxJ = 6;
	    
	    do {
	        codeList = leastCostFixedHop(at1, at2, costWeightedGraph, j);
	        num = codeList.size();
	        j++;
	    } while (num < maxNum && j < maxJ);

	    ArrayList<StopCostEntry> stopDetails = new ArrayList<StopCostEntry>();
	    //stopDetails = stopCostList
	    for (String code : codeList) {
	        Journey journey1 = leastHop(at1, code);
	        Journey journey2 = leastHop(at2, code);
	        int cost = journey1.totalCost() + journey2.totalCost();
	        int stop = journey1.totalHop() + journey2.totalHop();
	        StopCostEntry s = new StopCostEntry(code, stop, cost);
	        stopDetails.add(s);
	    }
	    
	    //list in ascending order of the number of stops
//	    Collections.sort(stopDetails, new StopCostSorting());
	    String meetStop = stopDetails.get(0).getCode();

	   //return the airport code of the best meeting point.
	    return meetStop;
	    
	}
	@Override
	//method returns the airport code of a best airport for the earliest meet based on two different airports location
	public String leastTimeMeetUp(String at1, String at2, String startTime) throws FlyingPlannerException {
		List<String> codeList = new LinkedList<String>();
		int num , j = 0;
		final int maxNum = 30;
	    final int maxJ = 6;
		do {
			codeList = leastCostFixedHop(at1, at2, costWeightedGraph, j);
			num = codeList.size();
			j++;
		} while (num < maxNum && j < maxJ);

		List<Integer> listingTime = new LinkedList<Integer>();
	    String startTimeF = startTime.substring(0, 2) + ":" + startTime.substring(2);
	    for (String code : codeList) {
	        Journey journey1 = leastTime(at1, code, 4);
	        Flight f1 = flight(journey1.getFlights().get(0));
	        String f1Time = f1.getFromGMTime();
	        int timeA1 = journey1.calculateTime(startTimeF, f1Time);
	        int timeB1 = journey1.totalTime();
	        int time1 = timeA1 + timeB1;

	        Journey j2 = leastTime(at2, code, 4);
	        Flight f2 = flight(j2.getFlights().get(0));
	        String f2Time = f2.getFromGMTime();
	        int timeA2 = j2.calculateTime(startTimeF, f2Time);
	        int timeB2 = j2.totalTime();
	        int time2 = timeA2 + timeB2;

	        // Add the maximum of the two times to the list of total times taken for each stopover
	        listingTime .add(Math.max(time1, time2));
	    }
	    // // Return the code of the stopover with the least total time taken
	    return codeList.get(listingTime .indexOf(Collections.min(listingTime )));
	}

	//returns a set of all the airport codes available in the system.
	public Set<String> getAirportList() {
		Set<String> aptCodeList = airports.keySet();
		return aptCodeList;
	}

class StopCostEntry {
	//store the airport code, the number of stops / connections in the journey and the total
	 //journey cost for every possible meet up airports for the meet up search.
		private String code;
		private int stop;
		private int cost;
		
		public StopCostEntry(String code, int stop, int cost) {
			this.code = code;
			this.stop = stop;
			this.cost = cost;
		}
		
		//returns the code of the meet up airport.
		public String getCode() {
			return code;
		}

		//returns the number of stops or connections in the journey to the meet up airport.
		public int getStop() {
			return stop;
		}

		public int getCost() {
			return cost;
		}

		public String toString() {
			return "" + code + " " + stop + " " + cost;
		}
}

//class StopCostSorting implements Comparator<StopCostEntry> {
//	@Override
//	public int compare(StopCostEntry s1, StopCostEntry s2) {
//		int stopCompare = Integer.compare(s1.getStop(), s2.getStop());
//		int costCompare = Integer.compare(s1.getCost(), s2.getCost());
//		
//		if (stopCompare == 0) {
//			return costCompare;
//		} else {
//			return stopCompare;
//		}
//	}
//}

@Override
	public Set<Airport> directlyConnected(Airport airport) {
		// TODO Auto-generated method stub
		return null;
	}
	
	}

