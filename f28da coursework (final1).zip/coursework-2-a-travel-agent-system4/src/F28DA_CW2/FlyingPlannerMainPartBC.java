package F28DA_CW2;

import java.io.FileNotFoundException;
import java.io.*;
import java.util.*;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultEdge;

public class FlyingPlannerMainPartBC {

	public static void main(String[] args) {

		// Your implementation should be in FlyingPlanner.java, this class is only to
		// run the user interface of your programme.

		FlyingPlanner fi;
		fi = new FlyingPlanner();
		try {
			
			fi.populate(new FlightsReader());
			Scanner scanner = new Scanner(System.in);
			Set<String> airportList = fi.getAirportList();

			String prgContinue = null;
			do {
			System.out.println("---------Welcome to Flight Planner Part BC!---------");
			String printError = "Invalid airport. Please enter again!";
	        String startPrint = "Please enter the start airport: ";
	        System.out.println(startPrint);
	        String start = scanner.nextLine();
	        while (!airportList.contains(start)) {
				System.err.println(printError);
				System.out.println(startPrint);
				start = scanner.nextLine();
	        }
				String startPrintA = "Please enter the destination airport: ";
		        System.out.println(startPrintA);
		        String dst = scanner.nextLine();
	        while (!airportList.contains(dst)) {
				System.err.println(printError);
				System.out.println(startPrintA);
				dst= scanner.nextLine();
			}
//			 System.out.println("How many airports would you like to avoid?");
//	        try {
//			int excluding = scanner.nextInt();
//			LinkedList<String> exclude = new LinkedList<String>();	
//			System.out.println("Enter the airport(s) you would like to avoid: ");				
//			
//				for(int i = 0; i < excluding+1; i++){
//					exclude.add(scanner.nextLine());
//				}
	      
	        System.out.println("Pick a section to begin with: ");
			System.out.println("1. (Part B): Journey Search ");
			System.out.println("2. (Part C): Meet-Up Search");
			System.out.println("Choose one: ");
			int search = scanner.nextInt();
	  
			switch (search) {
				case 1:
					printMenuB();
					int preference1 = scanner.nextInt();
							switch(preference1) {
								case 1:
									Journey mainJourney = fi.leastCost(start, dst);
									mainJourney.printJourney();
									break;
									
							case 2:
//									try {
//							    System.out.println("How many airports would you like to avoid?");
						        try {
								System.out.println("Enter the number of airports you would like to avoid: ");
								int excludeNumCost = scanner.nextInt();
								scanner.nextLine(); // Consume the newline character left over from nextInt()
	
								LinkedList<String> excludingCost = new LinkedList<String>();	
	
								System.out.println("Enter the airport(s) you would like to avoid: ");
								for (int i = 0; i < excludeNumCost; i++) {
								    excludingCost.add(scanner.nextLine()); 
								}
								System.out.println("Excluded airports: " + excludingCost); // Print the excluded airports using LinkedList's default toString() method
								Journey excJourney = fi.leastCost(start, dst, excludingCost);
								excJourney.printJourney();
								} catch (InputMismatchException ime) {
						        	   System.out.println("Error! Please start again" );
						        	   break;
						        }
									break;
							case 3:
								Journey journeyHop = fi.leastHop(start, dst);
								journeyHop.printJourney();
								break;
								
							case 4: 
								try {
								System.out.println("Enter the number of airports you would like to avoid: ");
								int excludeNumHop = scanner.nextInt();
								scanner.nextLine(); // Consume the newline character left over from nextInt()
	
								LinkedList<String> excludingHop = new LinkedList<String>();	
	
								System.out.println("Enter the airport(s) you would like to avoid: ");
								for (int i = 0; i < excludeNumHop; i++) {
								    excludingHop.add(scanner.nextLine()); 
								}
								System.out.println("Excluded airports: " + excludingHop);

								Journey journeyHopExc = fi.leastHop(start, dst, excludingHop);
								journeyHopExc.printJourney();
								} catch (InputMismatchException ime) {
						        	   System.out.println("Error! Please start again" );
						        	   break;
						        }
						
							case 5: 
								System.out.println("Maximum number of stops (2 - 5): ");
								int maxStop = scanner.nextInt();
								Journey journeyTime = fi.leastTime(start, dst, maxStop);
								journeyTime.printJourney();
								break;
							}
							break;
							
				case 2:
						printMenuC();
						int preference2 = scanner.nextInt();
							switch (preference2) {
							case 1:
							String costMeetUp = fi.leastCostMeetUp(start, dst);
							Journey meetUpLC1 = fi.leastCost(start, costMeetUp);
							Journey meetUpLC2 = fi.leastCost(dst, costMeetUp);
							meetUpLC1.printMeetUp(meetUpLC1 ,meetUpLC2, "Least Cost ", "");
							break;
							
							case 2:
								String hopMeetUp = fi.leastHopMeetUp(start, dst);
								Journey meetUpLH1 = fi.leastCost(start, hopMeetUp);
								Journey meetUpLH2= fi.leastCost(dst, hopMeetUp);
								meetUpLH1.printMeetUp(meetUpLH1,meetUpLH2, "Least Hop Journey ", "");
								System.out.println();
								break;
								
							case 3:
								System.out.println("\nPlease enter your start time (24-hour format): ");
								String startTime = scanner.next();
								String journeyMeetUp = fi.leastTimeMeetUp(start, dst, startTime);
								Journey meetUpLT1 = fi.leastTime(start, journeyMeetUp, 4);
								Journey meetUpLT2= fi.leastTime(dst, journeyMeetUp, 4);
								meetUpLT1.printMeetUp(meetUpLT1, meetUpLT2, "Least Total Journey Time ", startTime);
								break;
						}
					break;
					
			}
	        
			}while (prgContinue != null );
		} catch (FileNotFoundException | FlyingPlannerException e) {
			e.printStackTrace();
		}
	}

	private static void printMenuB() {
		System.out.println("Please select your preferred method : ");
		System.out.println("1. Least Cost Journey");
		System.out.println("2. Least Cost Journey (excluding aiport(s) selected)");
		System.out.println("3. Least Hops Journey");
		System.out.println("4. Least Hops Journey (excluding aiport(s) selected)");
		System.out.println("5. Least Journey Time");
		
	}
	private static void printMenuC() {
		System.out.println("Please select your preferred method : ");
		System.out.println("1. Least Cost Meet Up");
		System.out.println("2. Least Hops Meet Up");
		System.out.println("3. Least Journey Time");
		
	}

}


