package F28DA_CW2;
//FLIGHT
public class Flight implements IFlight {

	private String flightCode;
	private Airport toAirport;
	private Airport fromAirport;
	private String toGMTime;
	private String fromGMTime;
	private int cost;

	public Flight(String flightCode, Airport from, String fromTime, Airport to, String toTime, int cost){
		this.flightCode = flightCode;
		this.fromAirport = from;
		this.fromGMTime = fromTime;
		this.toAirport = to;
		this.toGMTime = toTime;
		this.cost = cost;
		
	}
	
	@Override
	public String getFlightCode() {
		return flightCode;
	}

	@Override
	public Airport getTo() {
		return toAirport;
	}

	@Override
	public Airport getFrom() {
		return fromAirport;
	}
	
	@Override
	public String getToGMTime() {
		return toGMTime;
	}
	@Override
	public String getFromGMTime() {
		return fromGMTime;
	}

	@Override
	public int getCost() {
		return cost;
	}
	public String toString() {
		return flightCode + " " + toAirport + " " +fromAirport+ " " +toGMTime+ " " +fromGMTime+ " " + cost;
	}


}
