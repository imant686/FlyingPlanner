package F28DA_CW2;
//AIRPORT 
import java.util.Set;

public class Airport implements IAirportPartB, IAirportPartC {
	
	private String airportCode;
	private String cityName;
	private String airportName;
	private Set<Airport> dicrectlyConnectedAirport;
	private int dicrectlyConnectedOrder;
	
	public Airport(String code, String city, String name) {
		this.airportCode = code;
		this.cityName = city;
		this.airportName = name;
		this.dicrectlyConnectedAirport = null;
		this.dicrectlyConnectedOrder = 0;
		
	}
	@Override
	public String getCode() {
		return airportCode;
	}
	public String getCity() {
		return cityName;
	}

	@Override
	public String getName() {
		return airportName;
	}

	@Override
	public void setDicrectlyConnected(Set<Airport> dicrectlyConnected) {
		this.dicrectlyConnectedAirport = dicrectlyConnected;;
	}

	@Override
	public Set<Airport> getDicrectlyConnected() {
		return dicrectlyConnectedAirport;
	}


	@Override
	public void setDicrectlyConnectedOrder(int order) {
		this.dicrectlyConnectedOrder = order;

	}

	@Override
	public int getDirectlyConnectedOrder() {
		return dicrectlyConnectedOrder;
	}
	
	public String toString() {
		return airportCode + " " + cityName + " " + airportName;
	}

}
