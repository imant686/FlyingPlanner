package F28DA_CW2;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultEdge;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;
import org.jgrapht.graph.SimpleGraph;

public class FlyingPlannerMainPartA {
	
	private static SimpleDirectedWeightedGraph<String, DefaultEdge> g = new SimpleDirectedWeightedGraph<>(DefaultEdge.class);
	
	private static Graph<String, DefaultEdge> getG() {
		return g;
	}
	

	public static void main(String[] args) {
		// The following code is from HelloJGraphT.java of the org.jgrapth.demo package
		
		System.err.println("The example code is from HelloJGraphT.java from the org.jgrapt.demo package.");
		System.err.println("Use similar code to build the small graph from Part A by hand.");
		System.err.println("Note that you will need to use a different graph class as your graph is not just a Simple Graph.");
		System.err.println("Once you understand how to build such graph by hand, move to Part B to build a more substantial graph.\n");
		// Code is from HelloJGraphT.java of the org.jgrapth.demo package (start)
		
        String v1 = "Edinburgh";
        String v2 = "Heathrow";
        String v3 = "Dubai";
        String v4 = "Sydney";
        String v5 = "Kuala Lumpur";

        // add the vertices
        g.addVertex(v1);
        g.addVertex(v2);
        g.addVertex(v3);
        g.addVertex(v4);
        g.addVertex(v5);
    
        // add edges to create a circuit
        DefaultEdge edge1 = g.addEdge(v1, v2);	//edinburgh to heathrow 
        g.setEdgeWeight(edge1, 80.0);
        
        DefaultEdge edge2 = g.addEdge(v2, v1);	//heathrow to edinburgh 
        g.setEdgeWeight(edge2, 80.0);
        
        DefaultEdge edge3 = g.addEdge(v2, v3);	//heathrow to dubai 
        g.setEdgeWeight(edge3, 130.0);
        
        DefaultEdge edge4 = g.addEdge(v3, v2);	//dubai to heathrow 
        g.setEdgeWeight(edge4, 130.0);
        
        DefaultEdge edge5 = g.addEdge(v2, v5);	//heathrow to sydney 
        g.setEdgeWeight(edge5, 570.0);
        
        DefaultEdge edge6 = g.addEdge(v5, v2);	//sydney to heathrow
        g.setEdgeWeight(edge6, 570.0);
        
        DefaultEdge edge7 = g.addEdge(v1, v3);	//edinburgh to dubai
        g.setEdgeWeight(edge7, 150.0);
        
        DefaultEdge edge8 = g.addEdge(v3, v1);	//dubai to edinburgh
        g.setEdgeWeight(edge8, 150.0);
        
        DefaultEdge edge9 = g.addEdge(v3, v5);	//dubai to kuala lumpur
        g.setEdgeWeight(edge9, 170.0);
        
        DefaultEdge edge10 = g.addEdge(v5, v3);	//kuala lumpur to dubai
        g.setEdgeWeight(edge10, 170.0);
        
        DefaultEdge edge11 = g.addEdge(v5, v4);	//kuala lumpur to sydney
        g.setEdgeWeight(edge11, 150.0);
        
        DefaultEdge edge12 = g.addEdge(v4, v5);	//sydney to kuala lumpur
        g.setEdgeWeight(edge12, 150.0);
        
        
        Set<String> vertexSet = g.vertexSet();
        String continuePrg = null;
        
        Scanner scanner = new Scanner (System.in);
        do {
        System.out.println("---------Welcome to The Flight Planner---------");
        System.out.println("The following airports are used :\n");
        System.out.println("FLIGHT \t\t\t\t\tCOST");
        
        for (DefaultEdge edges : g.edgeSet()) {
            double cost = g.getEdgeWeight(edges);
            String departureAirport = g.getEdgeSource(edges);
            String destinationAirport = g.getEdgeTarget(edges);
            System.out.printf("%-15s%-5s%-15s%5s%n", departureAirport, "<->", destinationAirport, "\t£" + cost);
        }
        String strError = "Invalid airport. Please enter again!";
        String printStart = "Please enter the start airport: ";
        System.out.println(printStart);
        String startAirport = scanner.nextLine();
        while (!vertexSet.contains(startAirport)) {
			System.err.println(strError);
			System.out.println(printStart);
			startAirport = scanner.nextLine();
		}
       
        String printStartA = "Please enter the destination airport: ";
        System.out.println(printStartA);
        String destination = scanner.nextLine();
        while (!vertexSet.contains(destination)) {
			System.err.println(strError);
			System.out.println(printStartA);
			destination = scanner.nextLine();
		}
        
        GraphPath<String, DefaultEdge> shortestPath = DijkstraShortestPath.findPathBetween(getG(), startAirport, destination);

	    List<String> vertexList = shortestPath.getVertexList();
	    List<DefaultEdge> edgeList = shortestPath.getEdgeList();
		    double costA = 0;
		    
		    System.out.println("Cheapest path: ");
		
		    for (int i = 0; i < edgeList.size(); i++) {
		        DefaultEdge edge = edgeList.get(i);
		        String startAp = g.getEdgeSource(edge);
		        String destinationAp = g.getEdgeTarget(edge);
		        double price = g.getEdgeWeight(edge);
		        costA += price;
		        System.out.printf("%d. %s -> %s\n", i + 1, startAp, destinationAp);
		    }
		    System.out.println("Flight cost: £" + costA);
		    System.out.println("Number of plane changes: " + (vertexList.size()-2));
		    
        } while (continuePrg != null );
	}
}
       

