package F28DA_CW2;
import java.util.*;
import java.util.List;

import org.jgrapht.GraphPath;

public class Journey implements IJourneyPartB<Airport, Flight>, IJourneyPartC<Airport, Flight> {
	private Airport fromAirport;
	private Airport toAirport;
	private GraphPath<Airport, FlightEdge> graphPath;
//	private List<Airport> airportList = graphPath.getVertexList();
//	private List<FlightEdge> flightList = graphPath.getEdgeList();


	public Journey(Airport from, Airport to, GraphPath<Airport, FlightEdge> gPath) {
		this.fromAirport = from;
		this.toAirport = to;
		this.graphPath = gPath;
		
	}
	@Override
	public List<String> getStops() {
	    List<Airport> airportList = graphPath.getVertexList(); // holds the list of Airport objects
	    List<String> aptCodeList = new LinkedList<>(); // will hold the list of airport codes
	    for (Airport airport : airportList) {
	        aptCodeList.add(airport.getCode()); // fill the list with airport codes
	    }
	    return aptCodeList; // return the list of airport codes in the graph path traveled

	}

	@Override
	//returns a list of flight codes for the flights in the graph path
	public List<String> getFlights() {
		List<FlightEdge> flightList = graphPath.getEdgeList();
		List<String> flightCodeList = new LinkedList<>();
		for (FlightEdge flightEdge : flightList) {
			Flight f = flightEdge.getFlight();
			flightCodeList.add(f.getFlightCode());
		}
		return flightCodeList;
	}

	@Override
	// returns the total number of hops 
	public int totalHop() {
		return getFlights().size();		
	}

	@Override
	// method calculates the total cost of a journey represented by the FlightEdge objects in the graphPath list.
	public int totalCost() {
	    int totalCost = 0;
	    for (FlightEdge f : graphPath.getEdgeList()) {
	        totalCost += f.getFlight().getCost();
	    }
	    return totalCost;
	}


	@Override
	//calculate and return the air time by iterating over the list of flights in the graphPath
	public int airTime() {
	    int totalMin = 0;
	    for (FlightEdge f : graphPath.getEdgeList()) {
	        totalMin += calculateTime(f.getFlight().getFromGMTime(), f.getFlight().getToGMTime());
	    }
	    return totalMin;
	}
	
	@Override
	//returns the sum of time in each connection of the journey.
	public int connectingTime() {
		List<FlightEdge> flightList = graphPath.getEdgeList();
		int totalMin = 0;
		for (int i = 0; i < flightList.size() - 1; i++) {
			FlightEdge f1 = flightList.get(i);
			FlightEdge f2 = flightList.get(i + 1);
			Flight getF1 = f1.getFlight();
			Flight getF2 = f2.getFlight();
			String startTime = getF1.getToGMTime();
			String endTime = getF2.getFromGMTime();
			totalMin += calculateTime(startTime, endTime);
		}
		return totalMin;

	}
	public int calculateTime(String from, String to) {
	    // Initialize variables to store the hours and minutes of the start and end times
	    int startHr, startMin, endHr, endMin = 0;
	    // Initialize variables to store the total minutes of the start and end times
	    int startTotalMin = 0, endTotalMin = 0;

	    // Check the length of the input strings to determine the time format
	    if (from.length() == 5 && to.length() == 5) { // Format: "HH:mm"
	        // Extract the hours and minutes from the strings using substring and convert them to integers
	        startHr = Integer.parseInt(from.substring(0, 2));
	        startMin = Integer.parseInt(from.substring(3, 5));
	        endHr = Integer.parseInt(to.substring(0, 2));
	        endMin= Integer.parseInt(to.substring(3, 5));
	    }
	    else if (from.length() == 4 && to.length() == 4) { // Format: "Hmm"
	        // Extract the hours and minutes from the strings using substring and convert them to integers
	        startHr = Integer.parseInt(from.substring(0, 2));
	        startMin = Integer.parseInt(from.substring(2, 4));
	        endHr = Integer.parseInt(to.substring(0, 2));
	        endMin = Integer.parseInt(to.substring(2, 4));
	    } 
	    else {
	        // Invalid input format, return 0 to indicate an error
	        return 0;
	    }

	    // If the end time is earlier in the day than the start time, add 24 hours to the end time
	    if (startHr > endHr || (startHr == endHr && startMin > endMin)) {
	        endHr += 24;
	    }

	    // Calculate the total minutes of the start and end times
	    startTotalMin = (startHr * 60) + startMin;
	    endTotalMin = (endHr * 60) + endMin;

	    // Calculate the difference between the end and start times in minutes and return the result
	    int timeDiff = endTotalMin - startTotalMin;
	    return timeDiff;
	}

	@Override
	//returns the sum of the total time in flight and the total time in connection of the journey.
	public int totalTime() {
		int totalTime = 0;
		totalTime = this.airTime() + this.connectingTime();
		return totalTime;
	}
	// converting the hours and minutes into string
	public String displayTime(int minute) {
		  return minute / 60 + " hours " + minute % 60 + " minutes";
	}
	//prints the details of the journey.
	public void printJourney() {
		System.out.println();
		String from = fromAirport.getCity() + " (" + fromAirport.getCode() + ")";
		String to = toAirport.getCity() + " (" + toAirport.getCode() + ")";
		System.out.println("Journey for " + from + " to " + to);
		System.out.printf("%-4s %-20s %-6s %-8s %-20s %-6s %n", "Leg", "Leave", "At", "On", "Arrive", "At");
		List<FlightEdge> flightList = graphPath.getEdgeList();
		
		for (int i = 1; i <= graphPath.getEdgeList().size(); i++) {
			Flight f = graphPath.getEdgeList().get(i-1).getFlight();
			Airport aFrom = f.getFrom();
			Airport aTo = f.getTo();
			String fromAirport = aFrom.getCity() + " (" + aFrom.getCode() + ")";
			String toAirport = aTo.getCity() + " (" + aTo.getCode() + ")";
			System.out.printf("%-4s %-20s %-6s %-8s %-20s %-6s %n", "" + i, fromAirport, f.getFromGMTime(), f.getFlightCode(), toAirport, f.getToGMTime());
		}
		
		System.out.println();
		System.out.printf("%-22s = £%d%n", "Total Journey Cost: ", totalCost());
		System.out.printf("%-22s = %s%n", "Total Air Time: ", displayTime(airTime()));
		if (connectingTime() != 0) {
			System.out.printf("%-22s = %s%n", "Total Connecting Time: ", displayTime(connectingTime()));
		}
		System.out.printf("%-22s = %s%n", "Total Time of Journey: ", displayTime(totalTime()));
	}
	
	//journey that going to be printed.
	private void printJourney(Journey j) {
	    List<FlightEdge> flightList = j.graphPath.getEdgeList();
	    if (flightList.isEmpty()) {
	        return;
	    }
	    
	    String from = j.fromAirport.getCity() + " (" + j.fromAirport.getCode() + ")";
	    String to = j.toAirport.getCity() + " (" + j.toAirport.getCode() + ")";
	    
	    System.out.println("Journey for " + from + " to " + to);
	    System.out.printf("%-4s %-20s %-6s %-8s %-20s %-6s %n", "Leg", "Leave", "At", "On", "Arrive", "At");
	    
	    int i = 1;
	    for (FlightEdge f : flightList) {
	        Flight ff = f.getFlight();
	        Airport aFrom = ff.getFrom();
	        Airport aTo = ff.getTo();
	        String fromAP = aFrom.getCity() + " (" + aFrom.getCode() + ")";
	        String toAP = aTo.getCity() + " (" + aTo.getCode() + ")";
	        
	        System.out.printf("%-4s %-20s %-6s %-8s %-20s %-6s %n", "" + i, fromAP, ff.getFromGMTime(), ff.getFlightCode(), toAP, ff.getToGMTime());
	        i++;
	    }
	    
	    System.out.println("\nTotal Cost of Journey £" + j.totalCost());
	    System.out.println("Total Air Time "+ j.displayTime(j.airTime()));
	    
	    if (j.connectingTime() != 0) {
	    	System.out.println("Total Connecting Time "  +j.displayTime(j.connectingTime()));
	    }
	    
	    System.out.println("Total Time of Journey "  + j.displayTime(j.totalTime()));
	    System.out.println("--------------------------------------------------------------");
	}
	
	//method that prints the details of the journeys for a meet up search.
	public void printMeetUp(Journey j1, Journey j2, String type, String startTime) {
	    System.out.println();
	    String from1 = j1.fromAirport.getCity() + " (" + j1.fromAirport.getCode() + ")";
	    String from2 = j2.fromAirport.getCity() + " (" + j2.fromAirport.getCode() + ")";
	    String to = j1.toAirport.getCity() + " (" + j1.toAirport.getCode() + ")";
	    
	    System.out.println("Preferred Meet-Up Airport with " + type + " from " + from1 + " and " + from2 + ": " + to);
	    System.out.println("--------------------------------------------------------------");
	    printJourney(j1);
	    printJourney(j2);
	    int sumCost = j1.totalCost() + j2.totalCost();
	    System.out.printf("%-22s = £%d%n", "Total Meet-Up Cost:", sumCost);

	    if (type.equalsIgnoreCase("Least Total Journey Time: ")) {
	        String startTimeF = startTime.substring(0, 2) + ":" + startTime.substring(2);
	        int time1 = j1.calculateTime(startTimeF, j1.graphPath.getEdgeList().get(0).getFlight().getFromGMTime()) + j1.totalTime();
	        int time2 = j2.calculateTime(startTimeF, j2.graphPath.getEdgeList().get(0).getFlight().getFromGMTime()) + j2.totalTime();
	        int totalTime = Math.max(time1, time2);

	        System.out.printf("%-22s = %s after The Departing Time: %s", "Estimated Meet Time", displayTime(totalTime), startTimeF);
	    }
	}

	@Override
	public int totalAirmiles() {

		return 0;
	}

}
